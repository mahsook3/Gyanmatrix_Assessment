var name=document.getElementById('Username').value;
var pass=document.getElementById('pass').value;

if(name==="biggorilla558" && pass==="penny"){
    alert("you are user correct");
}
else{
    alert("wrong");
}